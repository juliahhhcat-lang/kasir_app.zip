<?php
// Mulai sesi (selalu diperlukan saat berinteraksi dengan sesi)
session_start();
// Hapus semua variabel sesi
$_SESSION = array();
// Jika menggunakan sesi cookie, ini juga akan menghancurkan cookie sesi.
// Catatan: Ini akan menghancurkan sesi, dan bukan hanya data sesi!
if (ini_get("session.use_cookies")) {
$params = session_get_cookie_params();
setcookie(session_name(), '', time() - 42000,
$params["path"], $params["domain"],
$params["secure"], $params["httponly"]
);
}
// Akhirnya, hancurkan sesi
session_destroy();
// Arahkan pengguna kembali ke halaman login (index.php)
header("Location: ../index.php");
exit;
?>
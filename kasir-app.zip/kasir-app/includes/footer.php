<?php
// Pastikan koneksi ditutup di sini jika belum dilakukan di skrip utama
// if (isset($koneksi) && $koneksi) { $koneksi->close(); }
?>
</div> </div> <script
src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
</body>
</html>